<?php
include_once 'zbrojModel.php'; 


function zbroji ($a, $b) {
    return $a + $b; 
}
