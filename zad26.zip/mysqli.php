<?php

$mysqli = new mysqli("localhost", "user", "password", "database");

if($mysqli = true) {
    echo "uspješno spajanje na bazu"; 
}
else {
    echo "Nešto nije u redu"; 
}

?>
