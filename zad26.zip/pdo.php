<?php

try {
    
$dbh = new PDO('mysql:host=localhost; dbname=test', $user, $pass);

} catch (PDOException $e) 
    